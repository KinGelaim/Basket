export var p = 5;
export function foo() {};
export var q = {};

export default function bar() {};

var s = 4;

export { s };
export { s as t, q as m };