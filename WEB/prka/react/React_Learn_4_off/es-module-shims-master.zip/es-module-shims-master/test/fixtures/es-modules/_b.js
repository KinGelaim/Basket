export { c } from './_c.js';
export var b = 'b';
ordering.push('_b');