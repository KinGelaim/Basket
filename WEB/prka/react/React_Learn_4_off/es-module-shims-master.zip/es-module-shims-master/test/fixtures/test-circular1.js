export function f () {
  return 'f';
}

export { g } from './test-circular2.js';