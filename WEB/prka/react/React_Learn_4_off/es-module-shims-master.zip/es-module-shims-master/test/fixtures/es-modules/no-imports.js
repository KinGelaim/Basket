export var asdf = 'asdf';
export var obj = {};