export { t as q, p as z } from './export.js';
export default 4;
