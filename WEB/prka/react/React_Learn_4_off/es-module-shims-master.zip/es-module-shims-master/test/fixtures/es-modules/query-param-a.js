import { b } from './query-param-b.js';

export const a = 'a' + b;