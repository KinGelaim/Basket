export { d } from './_d.js';
export var c = 'c';
ordering.push('_c');