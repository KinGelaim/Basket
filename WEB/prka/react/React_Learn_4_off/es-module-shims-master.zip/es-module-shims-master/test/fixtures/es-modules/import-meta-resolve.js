export const url = import.meta.url;
export const resolve = import.meta.resolve;