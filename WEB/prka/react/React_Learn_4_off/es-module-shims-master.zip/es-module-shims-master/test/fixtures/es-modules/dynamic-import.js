export const before = 'before';

export function doImport() {
  return import('bare-dynamic-import');
}

export const after = 'after';
